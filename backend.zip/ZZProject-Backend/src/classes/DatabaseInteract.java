package classes;

import java.sql.*;
import java.util.ArrayList;

public class DatabaseInteract {
	private static Connection conn = null;
	private static ResultSet rs = null;
	private static PreparedStatement ps = null;
	
	public static void connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/FinalProject?user=root&password=root&useSSL=false");
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		} catch (ClassNotFoundException cnfe) {
			System.out.println("cnfe: " + cnfe.getMessage());
		}
	}
	
	public static void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (ps != null) {
				ps.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException sqle) {
			System.out.println("sqle closing streams: " + sqle.getMessage());
		}
	}
	
	public void addUser(User user) {
		String username = user.getUsername();
		try {
			connect();
			//get userID
			ps = conn.prepareStatement(" SELECT userID WHERE username=? ;");
			ps.setString(1, username);
			ps.executeQuery();
			
			int id = -1;
			while(rs.next()) {
				id = Integer.parseInt(rs.getString("userID"));
			}
			
			ps = conn.prepareStatement(" INSERT INTO Users (userID, username, password) VALUES(?, ?, ?);");
			ps.setString(1,  Integer.toString(id));
			ps.setString(2,  user.getUsername());
			ps.setString(3,  user.getPassword());
			ps.executeUpdate();
			
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		} finally {
			close();
		}
	}
	
	public User queryUser(String username) {
		String password = null;
		try {
			connect();
			ps = conn.prepareStatement("SELECT password FROM Users WHERE username=? ;");
			ps.setString(1,  username);
			ps.executeQuery();
			
			while(rs.next()) {
				password = rs.getString("password");
			}
			
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		} finally {
			close();
		}
		
		if(password != null && username != null) {
			User returnUser = new User(username, password);
			return returnUser;
		}
		
		return null;
	}
	
	public void addMessage (Message msg) {
		try {
			connect();
			ps = conn.prepareStatement(" INSERT INTO Users (messageID, text, audio, image, flagCount, loc_x, loc_y) VALUES(?, ?, ?, ?, ?, ?, ?);");
			ps.setString(1,  Integer.toString(msg.getMessageID()));
			ps.setString(2,  msg.getText());
			ps.setString(3,  msg.getAudio());
			ps.setString(4,  msg.getImage());
			ps.setString(5,Integer.toString(msg.getFlagCount()));
			ps.setString(6, Double.toString(msg.getLoc_x()));
			ps.setString(6, Double.toString(msg.getLoc_y()));
			ps.executeUpdate();
			
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		} finally {
			close();
		}
	}
	
	public Message queryMessage(int msgID) {
		String text = null;
		String audio = null;
		String image = null;
		int flagCount = -1;
		Double loc_x = null;
		Double loc_y = null;
		try {
			connect();
			ps = conn.prepareStatement("SELECT text, audio, image, flagCount, loc_x, loc_y FROM Messages WHERE messageID=? ;");
			ps.setString(1,  Integer.toString(msgID));
			ps.executeQuery();
			
			while(rs.next()) {
				text = rs.getString("text");
				audio = rs.getString("audio");
				image = rs.getString("image");
				flagCount = Integer.parseInt(rs.getString("flagCount"));
				loc_x = Double.parseDouble(rs.getString("loc_x"));
				loc_y = Double.parseDouble(rs.getString("loc_y"));
			}
			
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		} finally {
			close();
		}
		
		if(text != null && audio != null && image != null && flagCount != -1 && loc_x != null && loc_y != null) {
			Message returnMsg = new Message(msgID, text, audio, image, flagCount, loc_x, loc_y);
			return returnMsg;
		}
		
		return null;
	}
	
	public void deleteMessage(int msgid) {
		try {
			connect();
			ps = conn.prepareStatement("DELETE FROM Messages WHERE messageID=? ;");
			ps.setString(1, Integer.toString(msgid));
			ps.executeUpdate();
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		} finally {
			close();
		}
	}
	
	public ArrayList<User> getUsers () {
		ArrayList<User> returnArray = new ArrayList<User>();
		
		//get data
		try {
			connect();
			ps = conn.prepareStatement("SELECT username, password FROM Users;");
			rs = ps.executeQuery();
			while(rs.next()) {
				String username = rs.getString("username");
				String password = rs.getString("password");
				User addUser = new User(username, password);
				returnArray.add(addUser);
			}
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		} finally {
			close();
		}
		
		return returnArray;
	}
	
	public ArrayList<Message> getMessages () {
		ArrayList<Message> returnArray = new ArrayList<Message>();
		
		//get data
		try {
			connect();
			ps = conn.prepareStatement("SELECT messageID, text, audio, image, flagCount, loc_x, loc_y FROM Messages;");
			rs = ps.executeQuery();
			while(rs.next()) {
				int id = Integer.parseInt(rs.getString("messageID"));
				String text = rs.getString("text");
				String audio = rs.getString("audio");
				String image = rs.getString("image");
				int flagCount = Integer.parseInt(rs.getString("flagCount"));
				Double loc_x = Double.parseDouble(rs.getString("loc_x"));
				Double loc_y = Double.parseDouble(rs.getString("loc_y"));
				Message returnMsg = new Message(id, text, audio, image, flagCount, loc_x, loc_y);
				returnArray.add(returnMsg);
			}
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		} finally {
			close();
		}
		
		return returnArray;
	}
	
	
}