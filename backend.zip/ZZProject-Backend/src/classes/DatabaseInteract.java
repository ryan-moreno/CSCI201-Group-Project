package classes;

import java.util.List;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;

public class DatabaseInteract {
	private static Connection conn = null;
	private static ResultSet rs = null;
	private static PreparedStatement ps = null;
	
	public static void connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/FinalProjData?user=root&password=root&useSSL=false");
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		} catch (ClassNotFoundException cnfe) {
			System.out.println("cnfe: " + cnfe.getMessage());
		}
	}
	
	public static void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (ps != null) {
				ps.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException sqle) {
			System.out.println("sqle closing streams: " + sqle.getMessage());
		}
	}
	
	public void addUser(User user) {
		String username = user.getUsername();
		try {
			connect();
			//get userID
			ps = conn.prepareStatement(" SELECT userID FROM Users WHERE username=? ;");
			ps.setString(1, username);
			rs = ps.executeQuery();

			int id = -1;
			if(rs.next()) {
				id = Integer.parseInt(rs.getString("userID"));
			}
			
			if(id != -1) { //if user already exists
				return;
			}
			
			ps = conn.prepareStatement(" INSERT INTO Users (username, password) VALUES(?, ?);");
			ps.setString(1,  user.getUsername());
			ps.setString(2,  user.getPassword());
			ps.executeUpdate();
			
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage() + " in addUser");
		} finally {
			close();
		}
	}
	
	public User queryUser(String username) {
		String password = null;
		try {
			connect();
			ps = conn.prepareStatement("SELECT password FROM Users WHERE username=? ;");
			ps.setString(1,  username);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				password = rs.getString("password");
			}
			
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage() + " in queryUser");
		} finally {
			close();
		}
		
		if(password != null && username != null) {
			User returnUser = new User(username, password);
			return returnUser;
		}
		
		return null;
	}
	
	public void addMessage (Message msg) {
		try {
			connect();
			ps = conn.prepareStatement(" INSERT INTO Messages (text, audio, image, flagCount, loc_x, loc_y) VALUES(?, ?, ?, ?, ?, ?);");
			ps.setString(1,  msg.getText());
			ps.setString(2,  msg.getAudio());
			ps.setString(3,  msg.getImage());
			ps.setString(4,Integer.toString(msg.getFlagCount()));
			ps.setString(5, Double.toString(msg.getLoc_x()));
			ps.setString(6, Double.toString(msg.getLoc_y()));
			ps.executeUpdate();
			
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage() + " in addMessage");
		} finally {
			close();
		}
	}
	
	public Message queryMessage(int msgID) {
		String text = null;
		String audio = null;
		String image = null;
		int flagCount = -1;
		Double loc_x = null;
		Double loc_y = null;
		try {
			connect();
			ps = conn.prepareStatement("SELECT text, audio, image, flagCount, loc_x, loc_y FROM Messages WHERE messageID=? ;");
			ps.setString(1,  Integer.toString(msgID));
			rs = ps.executeQuery();
			
			while(rs.next()) {
				text = rs.getString("text");
				audio = rs.getString("audio");
				image = rs.getString("image");
				flagCount = Integer.parseInt(rs.getString("flagCount"));
				loc_x = Double.parseDouble(rs.getString("loc_x"));
				loc_y = Double.parseDouble(rs.getString("loc_y"));
			}
			
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage() + " in queryMessage");
		} finally {
			close();
		}
		
		if(text != null && audio != null && image != null && flagCount != -1 && loc_x != null && loc_y != null) {
			Message returnMsg = new Message(msgID, text, audio, image, flagCount, loc_x, loc_y);
			return returnMsg;
		}
		
		return null;
	}
	
	public void deleteMessage(int msgid) {
		//check if message exists
		Set<Integer> messageIDs = new HashSet<Integer>();
		ArrayList<Message> messages = getMessages();
		for(int i = 0; i < messages.size(); i++) {
			messageIDs.add(messages.get(i).getMessageID());
		}
		if(!messageIDs.contains(msgid)) {
			return;
		}
		
		//delete if message exists
		try {
			connect();
			ps = conn.prepareStatement("DELETE FROM Messages WHERE messageID=? ;");
			ps.setString(1, Integer.toString(msgid));
			ps.executeUpdate();
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage() + " in deleteMessage");
		} finally {
			close();
		}
	}
	
	public void clearDatabase() {
		try {
			connect();
			ps = conn.prepareStatement("DELETE FROM Messages;");
			ps.executeUpdate();
			ps = conn.prepareStatement("DELETE FROM Users;");
			ps.executeUpdate();
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage() + " in clearDatabase");
		} finally {
			close();
		}
	}
	
	public ArrayList<User> getUsers () {
		ArrayList<User> returnArray = new ArrayList<User>();
		
		//get data
		try {
			connect();
			ps = conn.prepareStatement("SELECT username, password FROM Users;");
			rs = ps.executeQuery();
			while(rs.next()) {
				String username = rs.getString("username");
				String password = rs.getString("password");
				User addUser = new User(username, password);
				returnArray.add(addUser);
			}
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage() + " in getUsers");
		} finally {
			close();
		}
		
		return returnArray;
	}
	
	public ArrayList<Message> getMessages () {
		ArrayList<Message> returnArray = new ArrayList<Message>();

		//get data
		try {
			connect();
			ps = conn.prepareStatement("SELECT messageID, text, audio, image, flagCount, loc_x, loc_y FROM Messages;");
			rs = ps.executeQuery();
			while(rs.next()) {
				int id = Integer.parseInt(rs.getString("messageID"));
				String text = rs.getString("text");
				String audio = rs.getString("audio");
				String image = rs.getString("image");
				int flagCount = Integer.parseInt(rs.getString("flagCount"));
				Double loc_x = Double.parseDouble(rs.getString("loc_x"));
				Double loc_y = Double.parseDouble(rs.getString("loc_y"));
				Message returnMsg = new Message(id, text, audio, image, flagCount, loc_x, loc_y);
				returnArray.add(returnMsg);
			}
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage() + " in getMessages");
		} finally {
			close();
		}
		
		return returnArray;
	}
	
	//returns the closest message
	public Message findClosestMessage(double x, double y) {
		ArrayList<Message> messages = getMessages();
		if(messages.size() == 0) {
			return null;
		} 
		double closestDistance = Double.MAX_VALUE;
		int indexClosest = 0;
		for(int i = 0; i < messages.size(); i++) {
			double mx = messages.get(i).getLoc_x();
			double my = messages.get(i).getLoc_y();
			double dist = Math.sqrt(Math.pow(x-mx, 2) + Math.pow(y-my, 2));
			if(dist < closestDistance) {
				closestDistance = dist;
				indexClosest = i;
			}
		}
		return messages.get(indexClosest);
	}
	
	//check if successful login, returns error message
	public String attemptLogin(String username, String password) {
		//create a map of usernames and passwords
		Map<String, String> userInfo = new HashMap<String, String>();
		ArrayList<User> users = getUsers();
		for(int i = 0; i < users.size(); i++) {
			userInfo.put(users.get(i).getUsername(), users.get(i).getPassword());
		}
		
		//make sure username exists
		if(!userInfo.containsKey(username)) {
			return "Username doesn't exist";
		}
		
		//make sure password matches
		if(!userInfo.get(username).equals(password)) {
			return "Username and password don't match";
		}		
		
		return "";
	}
	
	//check if successful signup, returns error message
	public String attemptSignup(String username, String password) {
		//create a map of usernames and passwords
		Map<String, String> userInfo = new HashMap<String, String>();
		ArrayList<User> users = getUsers();
		for(int i = 0; i < users.size(); i++) {
			userInfo.put(users.get(i).getUsername(), users.get(i).getPassword());
		}
		
		//make sure username isn't taken
		if(userInfo.containsKey(username)) {
			return "Username taken";
		}
		
		//add user
		User addThisUser = new User(username, password);
		addUser(addThisUser);
		
		return "";
	}
	
	//string is a json with keys messageID, text, audio, image,
	//flagCount, loc_x, loc_y
	public void addMessageFromSwift(String json) {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		Message message = null;
		try {
			message = gson.fromJson(json, Message.class);
		} catch(JsonParseException jpe) {
			return;
		}
		addMessage(message);
		
	}
	
	//input string has xlocation,ylocation
	public String getClosestMessageForSwift(String locations) {
		double x = Double.parseDouble(locations.split(",")[0]);
		double y = Double.parseDouble(locations.split(",")[1]);
		
		Message closest = findClosestMessage(x, y);
		
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String json = gson.toJson(closest);
		return json;
	}
	
	//returns a string json array with all the messages x,y locations
	public String getAllMessagesForSwift() {
		ArrayList<Message> messages = getMessages();
		List<Pair<Double,Double>> locations = new ArrayList<Pair<Double,Double>>();
		for(int i = 0; i < messages.size(); i++) {
			Pair<Double, Double> curPair = new Pair<Double, Double>(messages.get(i).getLoc_x(), messages.get(i).getLoc_y());
			locations.add(curPair);
		}
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String json = gson.toJson(locations);
		return json;
	}
	
	public static void main(String [] args) {
		DatabaseInteract db = new DatabaseInteract();
		
		db.clearDatabase();
		
		//SHOULD PRINT NOTHING
		System.out.println("EXPECT NOTHING: ");
		ArrayList<User> users = db.getUsers();
		for(int i = 0; i < users.size(); i++) {
			users.get(i).print();
		}
		
		ArrayList<Message> messages = db.getMessages();
		for(int i = 0; i < messages.size(); i++) {
			messages.get(i).print();
		}
		System.out.println();
		
		//ADDS USERS
		User testUser = new User("un1", "pw1");
		User testUser2 = new User("un2", "pw2");
		db.addUser(testUser);
		db.addUser(testUser2);
		
		//ADDS MESSAGES
		Message testMessage = new Message(1, "text1", "audio1", "image1", 0, -59.3, 53.98);
		Message testMessage2 = new Message(2, "text2", "audio2", "image2", 0, 98, -5.373);
		db.addMessage(testMessage);
		db.addMessage(testMessage2);
		
		//ATTEMPTS LOGINS
		System.out.println("EXPECT NOTHING:");
		String error = db.attemptLogin("un1", "pw1");
		System.out.println(error);
		
		System.out.println("EXPECT USERNAME NOT FOUND: ");
		error = db.attemptLogin("asdfkj", "password");
		System.out.println(error);
		System.out.println();
		
		System.out.println("EXPECT PASSWORD DOESN'T MATCH: ");
		error = db.attemptLogin("un1", "asdf");
		System.out.println(error);
		System.out.println();
		
		//ATTEMPTS SIGNUPS
		System.out.println("EXPECT NOTHING:");
		error = db.attemptSignup("un3", "pw3");
		System.out.println(error);
		
		System.out.println("EXPECT USERNAME TAKEN: ");
		error = db.attemptSignup("un1", "asdf");
		System.out.println(error);
		System.out.println();
		
		//SHOULD PRINT 3 users, 2 messages
		System.out.println("EXPECT 3 USERS 2 MESSAGES: ");
		users = db.getUsers();
		for(int i = 0; i < users.size(); i++) {
			users.get(i).print();
		}
		
		messages = db.getMessages();
		for(int i = 0; i < messages.size(); i++) {
			messages.get(i).print();
		}
		
		//SHOULD PRINT 2 messages in json format
		System.out.println("EXPECT 2 MESSAGES IN JSON FORMAT: ");
		String json = db.getAllMessagesForSwift();
		System.out.println(json);
		System.out.println();
		
		//SHOULD PRINT JSON FOR MESSAGE 1
		System.out.println("EXPECT JSON FOR MESSAGE 1: ");
		System.out.println(db.getClosestMessageForSwift("-51.2,49.2928"));
		System.out.println();
		
		//SHOULD PRINT User 2
		System.out.println("EXPECT USER 2");
		db.queryUser("un2").print();
		
		//SHOULD PRINT Message 1
		System.out.println("EXPECT MESSAGE 1: ");
		db.queryMessage(1).print();
		
		//DELETE MESSAGE
		db.deleteMessage(1);
		
		//SHOULD PRINT JUST MESSAGE 2
		System.out.println("EXPECT MESSAGE 2: ");
		messages = db.getMessages();
		for(int i = 0; i < messages.size(); i++) {
			messages.get(i).print();
		}
		
		//SHOULD PRINT MESSAGE 3
		json = "{\"messageID\": 3,\"text\": \"text3\",\"audio\": \"audio3\","
				+ "\"image\": \"image3\",\"flagCount\": 0,\"loc_x\": -20,\"loc_y\": 53.8}";
		db.addMessageFromSwift(json);
		db.queryMessage(3).print();
	}
}

class Pair<L,R> {
    private L x;
    private R y;
    public Pair(L x, R y){
        this.x = x;
        this.y = y;
    }
    public L getL(){ return x; }
    public R getR(){ return y; }
    public void setL(L x){ this.x = x; }
    public void setR(R y){ this.y = y; }
}