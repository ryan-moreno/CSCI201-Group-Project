package classes;

public class Message {
	private int messageID;
	private String text;
	private String audio;
	private String image;
	private int flagCount;
	private double loc_x;
	private double loc_y;	
	
	//constructor to create message with this information
	public Message(int m, String t, String a, String i, int f, double lx, double ly) {
		messageID = m;
		text = t;
		audio = a;
		image = i;
		flagCount = f;
		loc_x = lx;
		loc_y = ly;
	}

	//returns text
	public String getText() {
		return text;
	}

	//returns audio
	public String getAudio() {
		return audio;
	}
	
	//returns image
	public String getImage() {
		return image;
	}
	
	//returns flagCount
	public int getFlagCount() {
		return flagCount;
	}
	
	//returns loc_x
	public double getLoc_x() {
		return loc_x;
	}
	
	//returns loc_y
	public double getLoc_y() {
		return loc_y;
	}
	
	//returns messageID
	public int getMessageID() {
		return messageID;
	}
	
	//print for testing
	public void print() {
		System.out.println("messageID: " + messageID);
		System.out.println("text: " + text);
		System.out.println("audio: " + audio);
		System.out.println("image: " + image);
		System.out.println("flagCount: " + flagCount);
		System.out.println("loc_x: " + loc_x);
		System.out.println("loc_y: " + loc_y);
		System.out.println();
	}
	
}
