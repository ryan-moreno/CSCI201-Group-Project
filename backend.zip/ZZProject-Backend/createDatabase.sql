DROP DATABASE if exists FinalProjData;

CREATE DATABASE FinalProjData;

USE FinalProjData;

CREATE TABLE Users (
  userID int(11) primary key not null auto_increment,
  username varchar(50) not null,
  password varchar(50) not null
);

CREATE TABLE Messages (
  messageID int(11) primary key not null,
  text varchar(50) not null,
  audio varchar(50) not null,
  image varchar(50) not null,
  flagCount int(3) not null,
  loc_x FLOAT not null,
  loc_y FLOAT not null
);